-- Database: `amol`

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS `amol` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE `amol`;

-- Table structure for table `table_1`
CREATE TABLE IF NOT EXISTS `table_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_1` varchar(255) NULL ,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

