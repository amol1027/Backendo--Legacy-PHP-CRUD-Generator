// Main JavaScript file
document.addEventListener('DOMContentLoaded', function() {
    console.log('Application loaded');
});
